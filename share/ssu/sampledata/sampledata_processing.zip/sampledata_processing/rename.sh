#!/usr/bin/env bash

# Usage: bash rename.sh /path/to/files/ rename_file.txt [--dry-run]

# Check arguments
if [[ $# -lt 2 ]]; then
    echo "Usage: $0 /path/to/files/ rename_file.txt [--dry-run]"
    exit 1
fi

data_dir="$1"
rename_file="$2"
dry_run=false

# Check for optional --dry-run flag
if [[ "$3" == "--dry-run" ]]; then
    dry_run=true
    echo "⚠️  Dry-run mode: No files will be moved."
fi

# Validate directory
if [[ ! -d "$data_dir" ]]; then
    echo "Error: Directory '$data_dir' not found!"
    exit 1
fi

# Validate rename file
if [[ ! -f "$rename_file" ]]; then
    echo "Error: File '$rename_file' not found!"
    exit 1
fi

# Timestamp for backups
timestamp=$(date +"%Y%m%d_%H%M%S")

# Copy rename file to a backup
backup_file="${rename_file%.txt}_backup_${timestamp}.txt"
cp "$rename_file" "$backup_file"
echo "📂 Backup of mapping file saved as: $backup_file"

# Get root name (strip directory and extension)
base_name=$(basename "$rename_file" .txt)
output_file="${base_name}_results_${timestamp}.txt"

# Perform renaming inside given directory
while IFS=$'\t' read -r orig new; do
    src="$data_dir/$orig"
    dest="$data_dir/$new"

    if [[ ! -f "$src" ]]; then
        echo "Warning: '$orig' not found in $data_dir" >&2
        continue
    fi

    if [[ -e "$dest" ]]; then
        echo "Error: Destination '$new' already exists — skipping '$orig'" >&2
        continue
    fi

    if $dry_run; then
        echo "Would rename: $orig → $new"
    else
        mv -v -- "$src" "$dest"
    fi
done < "$rename_file" | tee "$output_file"

echo "✅ Results written to: $output_file"
